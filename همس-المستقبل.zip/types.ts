export enum Sender {
  USER = 'user',
  AI = 'ai',
}

export enum AppMode {
  CHAT = 'chat',
  IMAGE = 'image',
}

export interface GroundingChunk {
  web?: {
    uri: string;
    title: string;
  };
}

export interface Message {
  id: number;
  sender: Sender;
  text: string;
  image?: string;
  sources?: GroundingChunk[];
  isGenerating?: boolean;
}

export enum Role {
    USER = 'user',
    ADMIN = 'admin',
}

export interface User {
    id: string;
    name: string;
    email: string;
    role: Role;
}

export type View = 'login' | 'chat' | 'admin';
