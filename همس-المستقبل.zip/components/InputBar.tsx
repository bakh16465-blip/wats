
import React from 'react';
import { AppMode } from '../types';
import { SendIcon } from './Icons';

interface InputBarProps {
  input: string;
  setInput: (value: string) => void;
  handleSend: () => void;
  isLoading: boolean;
  appMode: AppMode;
}

const InputBar: React.FC<InputBarProps> = ({ input, setInput, handleSend, isLoading, appMode }) => {
  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };
  
  const placeholderText = appMode === AppMode.CHAT ? "اكتب سؤالك هنا..." : "صف الصورة التي تريد إنشاءها...";

  return (
    <div className="flex items-center gap-2 md:gap-4">
      <textarea
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyPress={handleKeyPress}
        placeholder={placeholderText}
        rows={1}
        className="flex-1 bg-white border border-gray-300 rounded-full py-3 px-6 text-gray-800 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 resize-none transition-shadow shadow-sm"
        disabled={isLoading}
      />
      <button
        onClick={handleSend}
        disabled={isLoading || !input.trim()}
        className="bg-gradient-to-br from-cyan-500 to-fuchsia-500 text-white rounded-full p-3.5 disabled:opacity-50 disabled:cursor-not-allowed hover:shadow-lg hover:scale-105 transform transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500"
      >
        {isLoading ? (
          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
        ) : (
          <SendIcon className="w-5 h-5" />
        )}
      </button>
    </div>
  );
};

export default InputBar;