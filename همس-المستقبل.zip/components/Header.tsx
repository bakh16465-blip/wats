import React from 'react';
import { AppMode, User, Role } from '../types';
import { MessageSquareIcon, ImageIcon, ShieldCheckIcon, LogoutIcon } from './Icons';

interface HeaderProps {
  appMode: AppMode;
  setAppMode: (mode: AppMode) => void;
  currentUser: User | null;
  onLogout: () => void;
  onNavigateToAdmin: () => void;
}

const Header: React.FC<HeaderProps> = ({ appMode, setAppMode, currentUser, onLogout, onNavigateToAdmin }) => {
  const isAdmin = currentUser?.role === Role.ADMIN;

  return (
    <header className="p-4 flex justify-between items-center border-b border-gray-200/80 bg-white/60 backdrop-blur-sm sticky top-0 z-20">
      <h1 className="text-xl md:text-2xl font-bold bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-transparent bg-clip-text">
        همس المستقبل
      </h1>
      <div className="flex items-center gap-4">
        <div className="hidden sm:flex items-center space-i-2 bg-gray-200/70 p-1 rounded-full border border-gray-300/80">
          <button
            onClick={() => setAppMode(AppMode.CHAT)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium flex items-center transition-all duration-300 ${
              appMode === AppMode.CHAT ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white shadow-md' : 'text-gray-600 hover:bg-gray-300/70'
            }`}
          >
            <MessageSquareIcon className="w-4 h-4 mis-2" />
            <span>محادثة</span>
          </button>
          <button
            onClick={() => setAppMode(AppMode.IMAGE)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium flex items-center transition-all duration-300 ${
              appMode === AppMode.IMAGE ? 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-white shadow-md' : 'text-gray-600 hover:bg-gray-300/70'
            }`}
          >
            <ImageIcon className="w-4 h-4 mis-2" />
            <span>إنشاء صورة</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
            {isAdmin && (
                <button onClick={onNavigateToAdmin} className="p-2.5 hover:bg-gray-200 rounded-full transition-colors" title="لوحة التحكم">
                    <ShieldCheckIcon className="w-6 h-6 text-gray-600" />
                </button>
            )}
            <button onClick={onLogout} className="p-2.5 hover:bg-gray-200 rounded-full transition-colors" title="تسجيل الخروج">
                <LogoutIcon className="w-6 h-6 text-gray-600" />
            </button>
        </div>
      </div>
    </header>
  );
};

export default Header;