import React, { useState } from 'react';
import { GoogleIcon } from './Icons';

interface LoginProps {
    onLogin: (email: string) => void;
    onGoogleLogin: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin, onGoogleLogin }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (email) {
            onLogin(email);
        }
    };

    return (
        <div className="relative z-10 flex items-center justify-center h-full">
            <div className="w-full max-w-md p-8 space-y-8 bg-white/40 backdrop-blur-2xl rounded-2xl shadow-lg border border-white/20 animate-zoom-in">
                <div className="text-center">
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-transparent bg-clip-text">
                        مرحباً بك في همس المستقبل
                    </h1>
                    <p className="mt-2 text-gray-600">سجّل الدخول للمتابعة إلى مساعدك الذكي</p>
                </div>
                <form className="space-y-6" onSubmit={handleSubmit}>
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700 text-right">
                            البريد الإلكتروني
                        </label>
                        <div className="mt-1">
                            <input
                                id="email"
                                name="email"
                                type="email"
                                autoComplete="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className="w-full px-4 py-3 bg-white/50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                                placeholder="admin@example.com"
                            />
                        </div>
                    </div>

                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-700 text-right">
                            كلمة المرور
                        </label>
                        <div className="mt-1">
                            <input
                                id="password"
                                name="password"
                                type="password"
                                autoComplete="current-password"
                                required
                                value={password}
                                onChange={(e) => setPassword('admin')}
                                className="w-full px-4 py-3 bg-white/50 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
                                placeholder="********"
                            />
                        </div>
                    </div>
                    <div>
                        <button
                            type="submit"
                            className="w-full flex justify-center py-3 px-4 border border-transparent rounded-lg shadow-lg text-sm font-medium text-white bg-gradient-to-br from-cyan-500 to-fuchsia-500 hover:scale-105 transform transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500"
                        >
                            تسجيل الدخول
                        </button>
                    </div>
                </form>

                <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-300/80"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                        <span className="px-2 bg-white/40 text-gray-500 rounded-md">أو المتابعة باستخدام</span>
                    </div>
                </div>

                <div>
                    <button
                        onClick={onGoogleLogin}
                        className="w-full inline-flex justify-center items-center py-3 px-4 border border-gray-300/80 rounded-lg shadow-sm bg-white/80 text-sm font-medium text-gray-700 hover:bg-gray-50/50 transition-all transform hover:scale-105"
                    >
                       <GoogleIcon className="w-5 h-5 mis-2"/>
                        <span>تسجيل الدخول باستخدام جوجل</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Login;