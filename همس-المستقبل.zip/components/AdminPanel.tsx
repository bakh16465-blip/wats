import React, { useState } from 'react';
import { User, Role } from '../types';
import { UsersIcon, SettingsIcon, TrashIcon, EditIcon, CloseIcon, ShieldCheckIcon } from './Icons';
import Modal from './Modal';

interface AdminPanelProps {
    users: User[];
    setUsers: React.Dispatch<React.SetStateAction<User[]>>;
    apiKeys: { gemini: string; googleSignIn: string };
    setApiKeys: React.Dispatch<React.SetStateAction<{ gemini: string; googleSignIn: string }>>;
    onClose: () => void;
}

type AdminTab = 'users' | 'settings';

const AdminPanel: React.FC<AdminPanelProps> = ({ users, setUsers, apiKeys, setApiKeys, onClose }) => {
    const [activeTab, setActiveTab] = useState<AdminTab>('users');
    const [tempApiKeys, setTempApiKeys] = useState(apiKeys);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [userToDelete, setUserToDelete] = useState<User | null>(null);

    const handleRoleChange = (userId: string, newRole: Role) => {
        setUsers(users.map(user => user.id === userId ? { ...user, role: newRole } : user));
    };

    const openDeleteConfirm = (user: User) => {
        setUserToDelete(user);
        setIsModalOpen(true);
    };

    const handleDeleteUser = () => {
        if (userToDelete) {
            setUsers(users.filter(user => user.id !== userToDelete.id));
            setIsModalOpen(false);
            setUserToDelete(null);
        }
    };

    const handleSaveApiKeys = () => {
        setApiKeys(tempApiKeys);
        alert('تم حفظ مفاتيح API بنجاح!');
    };

    return (
        <div className="relative z-20 flex items-center justify-center h-full p-4 md:p-6">
            <div className="w-full max-w-4xl h-full flex flex-col bg-white/40 backdrop-blur-2xl rounded-2xl shadow-lg border border-white/20 overflow-hidden animate-zoom-in">
                <header className="flex justify-between items-center p-4 border-b border-gray-200/80">
                    <div className="flex items-center gap-3">
                        <ShieldCheckIcon className="w-8 h-8 text-cyan-600" />
                        <h2 className="text-xl font-bold text-gray-800">لوحة تحكم المسؤول</h2>
                    </div>
                    <button onClick={onClose} className="p-2 hover:bg-gray-200/80 rounded-full transition-colors">
                        <CloseIcon className="w-6 h-6 text-gray-600" />
                    </button>
                </header>

                <div className="flex flex-1 overflow-hidden">
                    <nav className="w-48 p-4 border-l border-gray-200/80">
                        <ul className="space-y-2">
                            <li>
                                <button onClick={() => setActiveTab('users')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === 'users' ? 'bg-cyan-500 text-white shadow' : 'text-gray-600 hover:bg-gray-200/70'}`}>
                                    <UsersIcon className="w-5 h-5" />
                                    <span>إدارة المستخدمين</span>
                                </button>
                            </li>
                            <li>
                                <button onClick={() => setActiveTab('settings')} className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === 'settings' ? 'bg-cyan-500 text-white shadow' : 'text-gray-600 hover:bg-gray-200/70'}`}>
                                    <SettingsIcon className="w-5 h-5" />
                                    <span>إعدادات API</span>
                                </button>
                            </li>
                        </ul>
                    </nav>

                    <main className="flex-1 p-6 overflow-y-auto bg-gray-50/50">
                        {activeTab === 'users' && (
                            <div className="space-y-4">
                                <h3 className="text-lg font-semibold text-gray-700">قائمة المستخدمين ({users.length})</h3>
                                <div className="overflow-x-auto bg-white rounded-lg shadow border border-gray-200/80">
                                    <table className="w-full text-sm text-right text-gray-600">
                                        <thead className="bg-gray-100/70 text-xs text-gray-700 uppercase">
                                            <tr>
                                                <th scope="col" className="px-6 py-3">الاسم</th>
                                                <th scope="col" className="px-6 py-3">البريد الإلكتروني</th>
                                                <th scope="col" className="px-6 py-3">الصلاحية</th>
                                                <th scope="col" className="px-6 py-3">إجراءات</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {users.map(user => (
                                                <tr key={user.id} className="bg-white border-b hover:bg-gray-50/70">
                                                    <td className="px-6 py-4 font-medium text-gray-900">{user.name}</td>
                                                    <td className="px-6 py-4">{user.email}</td>
                                                    <td className="px-6 py-4">
                                                        <select value={user.role} onChange={(e) => handleRoleChange(user.id, e.target.value as Role)} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-cyan-500 focus:border-cyan-500 block w-full p-2">
                                                            <option value={Role.USER}>مستخدم</option>
                                                            <option value={Role.ADMIN}>مسؤول</option>
                                                        </select>
                                                    </td>
                                                    <td className="px-6 py-4">
                                                        <button onClick={() => openDeleteConfirm(user)} className="text-red-500 hover:text-red-700 p-2" title="حذف المستخدم">
                                                            <TrashIcon className="w-5 h-5" />
                                                        </button>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        )}
                        {activeTab === 'settings' && (
                             <div className="space-y-6 max-w-lg">
                                <h3 className="text-lg font-semibold text-gray-700">مفاتيح API</h3>
                                <div className="p-6 bg-white rounded-lg shadow border border-gray-200/80 space-y-4">
                                    <div>
                                        <label htmlFor="gemini-key" className="block mb-2 text-sm font-medium text-gray-900">مفتاح Google Gemini API</label>
                                        <input type="password" id="gemini-key" value={tempApiKeys.gemini} onChange={e => setTempApiKeys(k => ({...k, gemini: e.target.value}))} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-cyan-500 focus:border-cyan-500 block w-full p-2.5" />
                                    </div>
                                    <div>
                                        <label htmlFor="google-signin-key" className="block mb-2 text-sm font-medium text-gray-900">معرّف عميل Google Sign-In</label>
                                        <input type="password" id="google-signin-key" value={tempApiKeys.googleSignIn} onChange={e => setTempApiKeys(k => ({...k, googleSignIn: e.target.value}))} className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-cyan-500 focus:border-cyan-500 block w-full p-2.5" />
                                    </div>
                                    <button onClick={handleSaveApiKeys} className="px-5 py-2.5 text-sm font-medium text-white bg-cyan-500 rounded-lg hover:bg-cyan-600 focus:ring-4 focus:outline-none focus:ring-cyan-300">حفظ التغييرات</button>
                                </div>
                            </div>
                        )}
                    </main>
                </div>
            </div>
            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="تأكيد الحذف">
                <p className="text-gray-600">هل أنت متأكد أنك تريد حذف المستخدم <span className="font-bold">{userToDelete?.name}</span>؟ لا يمكن التراجع عن هذا الإجراء.</p>
                <div className="flex justify-end gap-3 mt-6">
                    <button onClick={() => setIsModalOpen(false)} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-lg hover:bg-gray-300">إلغاء</button>
                    <button onClick={handleDeleteUser} className="px-4 py-2 text-sm font-medium text-white bg-red-600 rounded-lg hover:bg-red-700">نعم، قم بالحذف</button>
                </div>
            </Modal>
        </div>
    );
};

export default AdminPanel;