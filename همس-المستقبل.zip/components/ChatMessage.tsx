
import React from 'react';
import { marked } from 'marked';
import { Message, Sender, GroundingChunk } from '../types';
import { BotIcon, UserIcon, CopyIcon, RefreshCwIcon, Volume2Icon, LinkIcon } from './Icons';
import useTextToSpeech from '../hooks/useTextToSpeech';

interface ChatMessageProps {
  message: Message;
  onRegenerate: (messageId: number) => void;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message, onRegenerate }) => {
  const isAI = message.sender === Sender.AI;
  const { play, isLoading: isTtsLoading, isPlaying } = useTextToSpeech(message.text);
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const createMarkup = (text: string) => {
    // Basic sanitization
    const sanitizedHtml = marked.parse(text, { breaks: true, gfm: true });
    return { __html: sanitizedHtml };
  };

  return (
    <div className={`flex items-start gap-4 ${isAI ? '' : 'flex-row-reverse'}`}>
      <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${isAI ? 'bg-gradient-to-br from-cyan-500 to-fuchsia-500' : 'bg-gray-300'}`}>
        {isAI ? <BotIcon className="w-6 h-6 text-white" isThinking={message.isGenerating} /> : <UserIcon className="w-6 h-6 text-gray-600" />}
      </div>
      <div className={`w-full max-w-2xl px-5 py-4 rounded-2xl shadow-sm ${isAI ? 'bg-white border border-gray-200' : 'bg-cyan-500 text-white'}`}>
        {message.isGenerating ? (
          <div className="flex items-center space-i-2">
             <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-75"></div>
             <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-150"></div>
             <div className="w-2 h-2 bg-gray-500 rounded-full animate-pulse delay-300"></div>
          </div>
        ) : (
          <>
            <div className={`max-w-none ${isAI ? 'prose prose-p:text-gray-700 prose-headings:text-gray-900 prose-strong:text-gray-900' : ''}`} dangerouslySetInnerHTML={createMarkup(message.text)} />
            {message.image && (
              <div className="mt-4">
                <img src={message.image} alt="Generated" className="rounded-lg max-w-sm w-full" />
              </div>
            )}
            {message.sources && message.sources.length > 0 && (
              <div className="mt-4 pt-3 border-t border-gray-200/80">
                <h4 className="text-sm font-semibold text-gray-500 mb-2">المصادر:</h4>
                <div className="flex flex-wrap gap-2">
                  {message.sources.map((source, index) => source.web && (
                    <a
                      key={index}
                      href={source.web.uri}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs bg-cyan-100/50 hover:bg-cyan-100 text-cyan-700 font-medium px-2 py-1 rounded-md flex items-center gap-1 transition-colors"
                    >
                      <LinkIcon className="w-3 h-3"/>
                      <span>{source.web.title || new URL(source.web.uri).hostname}</span>
                    </a>
                  ))}
                </div>
              </div>
            )}
            {isAI && (
              <div className="flex items-center gap-2 mt-4 text-gray-500">
                <button onClick={handleCopy} className="p-1.5 hover:bg-gray-200 rounded-full transition-colors" title={copied ? 'تم النسخ!' : 'نسخ'}>
                  <CopyIcon className="w-4 h-4" />
                </button>
                <button onClick={() => onRegenerate(message.id)} className="p-1.5 hover:bg-gray-200 rounded-full transition-colors" title="إعادة إنشاء">
                  <RefreshCwIcon className="w-4 h-4" />
                </button>
                <button onClick={play} disabled={isTtsLoading || isPlaying} className="p-1.5 hover:bg-gray-200 rounded-full transition-colors" title="استماع">
                  <Volume2Icon className={`w-4 h-4 ${isTtsLoading ? 'animate-spin' : ''} ${isPlaying ? 'text-cyan-500' : ''}`} />
                </button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default ChatMessage;