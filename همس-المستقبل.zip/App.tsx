import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Message, Sender, AppMode, View, User, Role } from './types';
import { generateChatResponse, generateImage } from './services/geminiService';
import Header from './components/Header';
import ChatMessage from './components/ChatMessage';
import InputBar from './components/InputBar';
import Login from './components/Login';
import AdminPanel from './components/AdminPanel';

// Mock Data
const MOCK_USERS: User[] = [
  { id: '1', name: 'عمران العمراني', email: 'admin@example.com', role: Role.ADMIN },
  { id: '2', name: 'مستخدم تجريبي', email: 'user@example.com', role: Role.USER },
  { id: '3', name: 'علياء أحمد', email: 'alia@example.com', role: Role.USER },
];

const App: React.FC = () => {
  // App State
  const [currentView, setCurrentView] = useState<View>('login');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>(MOCK_USERS);
  const [apiKeys, setApiKeys] = useState({ gemini: 'sk-xxxxxxxxxxxx', googleSignIn: 'xxxxxxxxxxxx.apps.googleusercontent.com' });

  // Chat State
  const [messages, setMessages] = useState<Message[]>([
    {
      id: Date.now(),
      sender: Sender.AI,
      text: 'أهلاً بك في "همس المستقبل"! كيف يمكنني مساعدتك اليوم؟',
      sources: [],
    },
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [appMode, setAppMode] = useState<AppMode>(AppMode.CHAT);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (currentView === 'chat') {
      scrollToBottom();
    }
  }, [messages, currentView]);

  // --- Handlers ---
  const handleLogin = (email: string) => {
    const user = users.find(u => u.email === email);
    if (user) {
      setCurrentUser(user);
      setCurrentView('chat');
    } else {
      // For simplicity, create a new user if not found
      const newUser = { id: String(Date.now()), name: email.split('@')[0], email, role: Role.USER };
      setUsers(prev => [...prev, newUser]);
      setCurrentUser(newUser);
      setCurrentView('chat');
    }
  };
  
  const handleGoogleLogin = () => {
    // In a real app, you'd use the Google Sign-In library.
    // Here, we'll just log in the admin for demonstration.
    const adminUser = users.find(u => u.role === Role.ADMIN);
    if(adminUser) {
        setCurrentUser(adminUser);
        setCurrentView('chat');
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('login');
  };

  const handleSend = useCallback(async (prompt: string) => {
    if (!prompt.trim() || isLoading) return;

    const userMessage: Message = { id: Date.now(), sender: Sender.USER, text: prompt };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    const aiMessageId = Date.now() + 1;
    const placeholderMessage: Message = { id: aiMessageId, sender: Sender.AI, isGenerating: true, text: '' };
    setMessages((prev) => [...prev, placeholderMessage]);

    try {
      if (appMode === AppMode.CHAT) {
        const { text, sources } = await generateChatResponse(prompt);
        setMessages((prev) => prev.map((msg) => msg.id === aiMessageId ? { ...msg, text, sources, isGenerating: false } : msg));
      } else {
        const imageUrl = await generateImage(prompt);
        setMessages((prev) => prev.map((msg) => msg.id === aiMessageId ? { ...msg, text: `صورة لـ: ${prompt}`, image: imageUrl, isGenerating: false } : msg));
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'حدث خطأ غير متوقع.';
      setMessages((prev) => prev.map((msg) => msg.id === aiMessageId ? { ...msg, text: `عذراً، حدث خطأ: ${errorMessage}`, isGenerating: false } : msg));
    } finally {
      setIsLoading(false);
    }
  }, [appMode, isLoading]);

  const handleRegenerate = async (messageId: number) => {
    const lastUserMessage = [...messages].reverse().find((m) => m.sender === Sender.USER);
    if (lastUserMessage) {
      setMessages((prev) => prev.filter((msg) => msg.id !== messageId));
      await handleSend(lastUserMessage.text);
    }
  };

  const renderContent = () => {
    switch (currentView) {
      case 'login':
        return <Login onLogin={handleLogin} onGoogleLogin={handleGoogleLogin} />;
      case 'admin':
        return (
          <AdminPanel
            users={users}
            setUsers={setUsers}
            apiKeys={apiKeys}
            setApiKeys={setApiKeys}
            onClose={() => setCurrentView('chat')}
          />
        );
      case 'chat':
      default:
        return (
            <div className="relative z-10 flex items-center justify-center h-full p-4 md:p-6">
                <div className="w-full max-w-4xl h-full flex flex-col bg-white/40 backdrop-blur-2xl rounded-2xl shadow-lg border border-white/20 overflow-hidden animate-zoom-in">
                    <Header
                      appMode={appMode}
                      setAppMode={setAppMode}
                      currentUser={currentUser}
                      onLogout={handleLogout}
                      onNavigateToAdmin={() => setCurrentView('admin')}
                    />
                    <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
                      {messages.map((msg) => <ChatMessage key={msg.id} message={msg} onRegenerate={handleRegenerate} />)}
                      <div ref={chatEndRef} />
                    </main>
                    <footer className="p-4 border-t border-gray-200/80 bg-white/60 backdrop-blur-sm">
                      <InputBar input={input} setInput={setInput} handleSend={() => handleSend(input)} isLoading={isLoading} appMode={appMode} />
                      <div className="text-center text-xs text-gray-500 mt-3">
                        <p>مبرمج: عمران عبدالله العمراني | حقوق النشر © 2027 | هاتف: 779338021</p>
                      </div>
                    </footer>
                </div>
            </div>
        );
    }
  };

  return (
    <div className="bg-slate-50 text-gray-800 h-screen font-sans overflow-hidden relative">
      <div className="absolute inset-0 z-0 bg-repeat" style={{ backgroundImage: 'radial-gradient(rgba(0, 0, 0, 0.05) 1px, transparent 1px)', backgroundSize: '2rem 2rem' }} />
      <div className="absolute -top-32 -right-32 h-[500px] w-[500px] bg-cyan-200/20 rounded-full blur-3xl" style={{ animation: 'drift-1 20s infinite ease-in-out' }} />
      <div className="absolute -bottom-32 -left-32 h-[500px] w-[500px] bg-fuchsia-200/20 rounded-full blur-3xl" style={{ animation: 'drift-2 25s infinite ease-in-out alternate' }} />
      {renderContent()}
    </div>
  );
};

export default App;