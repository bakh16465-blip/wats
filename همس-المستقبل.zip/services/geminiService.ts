
import { GoogleGenAI, Modality } from "@google/genai";

let ai: GoogleGenAI | null = null;

// This function lazily initializes the GoogleGenAI client.
// It prevents the app from crashing on load if the API key is not set.
function getAiClient(): GoogleGenAI {
    if (!ai) {
        if (!process.env.API_KEY) {
            throw new Error("لم يتم تعيين مفتاح Gemini API. يرجى تكوينه.");
        }
        ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    }
    return ai;
}

export async function generateChatResponse(prompt: string): Promise<{ text: string, sources: any[] }> {
    try {
        const client = getAiClient();
        const response = await client.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                tools: [{ googleSearch: {} }],
            },
        });

        const text = response.text;
        const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        return { text, sources };
    } catch (error) {
        console.error("Error in generateChatResponse:", error);
        throw new Error(error instanceof Error ? error.message : "فشل في الحصول على رد الدردشة من Gemini API.");
    }
}

export async function generateImage(prompt: string): Promise<string> {
    try {
        const client = getAiClient();
        const response = await client.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: {
                parts: [{ text: prompt }],
            },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });

        for (const part of response.candidates?.[0]?.content.parts || []) {
            if (part.inlineData) {
                const base64ImageBytes: string = part.inlineData.data;
                return `data:image/png;base64,${base64ImageBytes}`;
            }
        }
        throw new Error("لم يتم العثور على بيانات الصورة في الاستجابة.");

    } catch (error) {
        console.error("Error in generateImage:", error);
        throw new Error(error instanceof Error ? error.message : "فشل في إنشاء صورة باستخدام Gemini API.");
    }
}

export async function generateSpeech(text: string): Promise<string> {
    try {
        const client = getAiClient();
        const response = await client.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });

        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if (!base64Audio) {
            throw new Error("لم يتم استلام بيانات صوتية من الواجهة البرمجية.");
        }
        return base64Audio;
    } catch (error) {
        console.error("Error in generateSpeech:", error);
        throw new Error(error instanceof Error ? error.message : "فشل في إنشاء الكلام باستخدام Gemini API.");
    }
}
